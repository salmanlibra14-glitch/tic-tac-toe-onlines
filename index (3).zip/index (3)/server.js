const express = require("express");
const http = require("http");
const path = require("path");
const { Server } = require("socket.io");

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static(path.join(__dirname)));

let players = { H:null, S:null };
let turn = "H";

io.on("connection", (socket) => {
  if(!players.H){ players.H = socket.id; socket.emit("assign","H"); }
  else if(!players.S){ players.S = socket.id; socket.emit("assign","S"); }
  else{ socket.emit("full"); return; }

  socket.on("makeMove", (data) => {
    if(socket.id === players[turn]){
      io.emit("updateBoard", data);
      turn = turn==="H"?"S":"H";
    }
  });

  socket.on("resetGame", () => {
    turn="H";
    io.emit("resetBoard");
  });

  socket.on("disconnect", () => {
    if(players.H===socket.id) players.H=null;
    if(players.S===socket.id) players.S=null;
  });
});

server.listen(3000, ()=>{ console.log("Server running on http://localhost:3000"); });
